// setTimeout(()=>{
//     console.log("Hello world")
// }, 1000)
// let counter = 0
// let x = setInterval(()=>{
//     console.log("Hello world", counter)
//     if(counter == 10) {
//         clearInterval(x)
//     }
//     counter++
// }, 1000)