/**
 * try {
 *  code
 * } catch(err) {
 *  code
 * } finally {
 *  code 
 * }
 * 
 * 
 */

// try {
//     print("hello world")
// }catch(err) {
//     console.log(err.message)
//     console.log("Use console.log instead")
// }
let rts = "" 
try {
    // if(!str) throw "String cannot be empty"
    console.log(str)
}catch(err) {
    console.log(err.message)
}