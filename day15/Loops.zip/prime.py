from main import primeChecker
i=0
while(True):
    # print(i)
    if primeChecker(i) == None:
        pass
    else:
        print(primeChecker(i))
    i+=1