// console.log("Hello from HTML")
        // console.log("Hello world")
        // console.log("How are you?")

        // console.log("Hello world", "How are you?")
        // console.log("Hello world"+" How are you?")

        // x = 10, y=20
        // console.log("The value of x is", x)
        // console.log("The value of x is "+x)
        // console.log(`The value of x is ${x+y}`)

        // variable declaration method 
        // let, var & const

        // let & const (local scope variable '' '' )
        // const x = 10
        // console.log(x)
        // {
        //     const x = 20
        //     console.log(x)
        // }
        // // x = 30
        // console.log(x)


        // var (global scope)
        // var x = 10
        // console.log(x)
        // {
        //     var x = 20
        //     console.log(x)
        // }
        // // x = 30
        // console.log(x)