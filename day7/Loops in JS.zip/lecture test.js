// Question 1: JS Program to check Palindrome Number

// let mainStr = prompt("Enter the string")
// // let mainStr = "Hriday"
// let reverseStr = mainStr.split("")
// let finalStr = ""
// for(let i=reverseStr.length-1; i>=0; i--) {
//     // console.log(reverseStr[i])
//     finalStr = finalStr+reverseStr[i]
// }
// console.log(finalStr)


// Question 2: JS Program to print all multiples of 3 & 5 in an Interval of 1 to 200

// for(let i=1; i<=200; i++) {
//     if(i%3==0 && i%5==0) {
//         console.log(i)
//     }
// }


// Question 3: JS Program to find the factorial of a number
// let inp = 5
// let inp = Number(prompt("Enter your number"))
// let fact = 1
// for(let i=1; i<=inp; i++) {
//     fact = fact*i
// }
// console.log(fact)